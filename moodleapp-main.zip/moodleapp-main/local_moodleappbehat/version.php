<?php

/**
 * This plugin has been auto-generated, please don't modify it.
 */

defined('MOODLE_INTERNAL') || die;

$plugin->version = {{ pluginVersion }};
$plugin->requires = 2016052300;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '{{ appVersion }}';
$plugin->component = 'local_moodleappbehat';
